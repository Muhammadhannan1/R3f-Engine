import { useState, Suspense, useRef } from "react";
// import reactLogo from './assets/react.svg'
// import viteLogo from '/vite.svg'
import "./App.css";
import { Canvas } from "@react-three/fiber";
import { Environment, OrbitControls } from "@react-three/drei";
import { Loader } from "./components/Scene";
import {
  Selection,
  Select,
  EffectComposer,
  Outline,
} from "@react-three/postprocessing";
function App() {
  const [meshName, setMeshName] = useState("");
  const setName = (name) => {
    setMeshName(name);
  };
  const popUpBox = useRef(null);
  return (
    <>
      <div
        style={{
          position: "absolute",
          zIndex: "1",
          padding: "1rem",
          top: "10%",
          backgroundColor: "black",
          width: "15%",
        }}
      >
        <div className="accordion" id="accordionExample">
          <div className="accordion-item">
            <h2 className="accordion-header" id="headingOne">
              <button
                className="accordion-button"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#collapseOne"
                aria-expanded="false"
                aria-controls="collapseOne"
              >
                B1 Parts
              </button>
            </h2>
            <div
              id="collapseOne"
              className="accordion-collapse collapse show"
              aria-labelledby="headingOne"
              data-bs-parent="#accordionExample"
            >
              <div className="accordion-body">
                <ul>
                  <li onClick={() => setName("B1_1_1")}>
                    <a href="#">B1-1</a>
                  </li>
                  <li onClick={() => setName("B1_1_2")}>
                    <a href="#">B1-2</a>
                  </li>
                  <li onClick={() => setName("B1_1_3")}>
                    <a href="#">B1-3</a>
                  </li>
                  <li onClick={() => setName("B1_1_4")}>
                    <a href="#">B1-4</a>
                  </li>
                  <li onClick={() => setName("B1_1_5")}>
                    <a href="#">B1-5</a>
                  </li>
                  <li onClick={() => setName("B1_1_6")}>
                    <a href="#">B1-6</a>
                  </li>
                  <li onClick={() => setName("B1_1_7")}>
                    <a href="#">B1-7</a>
                  </li>
                  <li onClick={() => setName("B1_1_8")}>
                    <a href="#">B1-8</a>
                  </li>
                  <li onClick={() => setName("B1_1_9")}>
                    <a href="#">B1-9</a>
                  </li>
                  <li onClick={() => setName("B1_1_10")}>
                    <a href="#">B1-10</a>
                  </li>
                  <li onClick={() => setName("B1_1_11")}>
                    <a href="#">B1-11</a>
                  </li>
                  <li onClick={() => setName("B1_1_12")}>
                    <a href="#">B1-12</a>
                  </li>
                  <li onClick={() => setName("B1_1_3")}>
                    <a href="#">B1-13</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          <div className="accordion-item">
            <h2 className="accordion-header" id="headingTwo">
              <button
                className="accordion-button collapsed"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#collapseTwo"
                aria-expanded="false"
                aria-controls="collapseTwo"
              >
                B2 Parts
              </button>
            </h2>
            <div
              id="collapseTwo"
              className="accordion-collapse collapse"
              aria-labelledby="headingTwo"
              data-bs-parent="#accordionExample"
            >
              <div className="accordion-body">
                <ul>
                  <li onClick={() => setName("B2_1_1")}>
                    <a href="#">B2-1</a>
                  </li>
                  <li onClick={() => setName("B2_1_2")}>
                    <a href="#">B2-2</a>
                  </li>
                  <li onClick={() => setName("B2_1_3")}>
                    <a href="#">B2-3</a>
                  </li>
                  <li onClick={() => setName("B2_1_4")}>
                    <a href="#">B2-4</a>
                  </li>
                  <li onClick={() => setName("B2_1_5")}>
                    <a href="#">B2-5</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          <div className="accordion-item">
            <h2 className="accordion-header" id="headingThree">
              <button
                className="accordion-button collapsed"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#collapseThree"
                aria-expanded="false"
                aria-controls="collapseThree"
              >
                B3 parts
              </button>
            </h2>
            <div
              id="collapseThree"
              className="accordion-collapse collapse"
              aria-labelledby="headingThree"
              data-bs-parent="#accordionExample"
            >
              <div className="accordion-body">
                <ul>
                  <li onClick={() => setName("B3_1")}>
                    <a href="#">B3-1</a>
                  </li>
                  <li onClick={() => setName("B3_2")}>
                    <a href="#">B3-2</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          <div className="accordion-item">
            <h2 className="accordion-header" id="headingFour">
              <button
                className="accordion-button collapsed"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#collapseFour"
                aria-expanded="false"
                aria-controls="collapseFour"
              >
                B4 parts
              </button>
            </h2>
            <div
              id="collapseFour"
              className="accordion-collapse collapse"
              aria-labelledby="headingFour"
              data-bs-parent="#accordionExample"
            >
              <div className="accordion-body">
                <ul>
                  <li onClick={() => setName("B4_1")}>
                    <a href="#">B4-1</a>
                  </li>
                  <li onClick={() => setName("B4_1_2")}>
                    <a href="#">B4-2</a>
                  </li>
                  <li onClick={() => setName("B4_1_3")}>
                    <a href="#">B4-3</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div
        id="popUpBox"
        ref={popUpBox}
        style={{
          position: "absolute",
          top: "8%",
          right: "5%",
          padding: "20px",
          width: "20%",
          height: "17%",
          backgroundColor: "green",
          color: "white",
          borderRadius: "15px",
          fontWeight: "bold",
          fontSize: "20px",
          display: "none",
        }}
      >
        {meshName.startsWith("B2") === true ? (
          <>
            <div>Plug {meshName}</div>
            o'clock position
          </>
        ) : (
          <>
            <p>plug {meshName}</p>
            <p>Stage</p>
            Blades Leading Edge / Stage Trailing Edge
          </>
        )}
      </div>

      {/* <Environment preset="sunset" background /> */}
      <Canvas>
        <OrbitControls enablePan={false} enableRotate={false} />
        <ambientLight intensity={0.7} />
        <pointLight position={[10, 10, 10]} />
        <Suspense fallback={null}>
          {/* <Selection>
        <EffectComposer multisampling={8} autoClear={false}>
          <Outline blur visibleEdgeColor="white" edgeStrength={100} width={500} />
        </EffectComposer>
          <Loader meshName={meshName} boxRef = {popUpBox} />
          </Selection> */}

          <Selection>
            <EffectComposer multisampling={8} autoClear={false}>
              <Outline
                blur
                visibleEdgeColor="white"
                edgeStrength={100}
                width={500}
              />
            </EffectComposer>
            <Loader meshName={meshName} boxRef={popUpBox} />
          </Selection>
        </Suspense>
      </Canvas>
    </>
  );
}

export default App;
