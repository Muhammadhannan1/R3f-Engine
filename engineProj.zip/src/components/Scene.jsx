import {
  Html,
  OrbitControls,
  PerspectiveCamera,
  useProgress,
} from "@react-three/drei";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader";
import { useLoader, useThree, useFrame } from "@react-three/fiber";
import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { Vector3 } from "three";
import { Selection, Select, EffectComposer, Outline } from '@react-three/postprocessing'

export const Loader = ({ meshName, boxRef }) => {
  const gltf = useLoader(GLTFLoader, "src/assets/models/engine.glb");
  const [mesh, setMesh] = useState(null);
  const cameraRef = useRef();
  const [selectedMeshName, setSelectedMeshName] = useState(null);
  const { camera,gl } = useThree();
  const selectedObjectRef = useRef(null);
  const ref = useRef(null);

  const findMeshByName = (name) => {
    const findMeshRecursive = (object, name) => {
      if (object.name === name && object.isMesh) {
        return object;
      }
      for (const child of object.children) {
        const found = findMeshRecursive(child, name);
        if (found) return found;
      }
      return null;
    };

    return findMeshRecursive(gltf.scene, name);
  };

  const focusCameraOnObject = (objectToFocus) => {
    if (objectToFocus) {
      const distance = 1; // Adjust the initial distance as needed for the desired zoom level
      // const targetPosition = objectToFocus.position.clone().add(new THREE.Vector3(0, 0, distance));
      const targetPosition = objectToFocus.position.clone();
      const duration = 1200; // Animation duration in milliseconds
      const startTime = performance.now(); // Record the start time
      //console.log(objectToFocus.material);
      // Function to update camera position and orientation
      const updateCamera = () => {
        const currentTime = performance.now();
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1); // Ensure progress is between 0 and 1

        // Interpolate camera position
        camera.position.lerp(targetPosition, progress);

        // Update camera orientation
        camera.lookAt(objectToFocus.position);
        camera.fov = 4; // Set the desired FOV here
        const newColor = new THREE.Color(4, 6, 8); // Replace with your desired color
        objectToFocus.material.color.copy(newColor);
        objectToFocus.material.needsUpdate = true;
        // If the animation is not finished, request the next frame
        if (progress < 1) {
          requestAnimationFrame(updateCamera);
        }
      };
      // Start the animation
      updateCamera();
    }
  };

  // Event handler for button click

  const useFullChildrens =
    gltf.scene.children[0].children[3].children[0].children;
  // console.log(gltf.scene.children[0].children[3].children[0].children[2].children)
  //console.log(useFullChildrens);
  // console.log(gltf.scene.children)

  useEffect(() => {
    if (meshName !== "") {
      var childrens;
      if (meshName.startsWith("B1")) {
        childrens =
          gltf.scene.children[0].children[3].children[0].children[2].children;
        console.log(meshName);
      } else if (meshName.startsWith("B2")) {
        childrens =
          gltf.scene.children[0].children[3].children[0].children[1].children;
      } else if (meshName.startsWith("B3") || meshName.startsWith("B4")) {
        childrens =
          gltf.scene.children[0].children[3].children[0].children[0].children;
      }

      const mesh = childrens.find((mesh) => mesh.name === meshName);
      if (mesh) {
        // Do something with the found mesh, e.g., manipulate it
        //console.log("Found mesh:", mesh);
        focusCameraOnObject(mesh);
         selectedObjectRef.current = mesh;  
        const box = boxRef.current;
        box.style.display = "block";
        setSelectedMeshName(meshName);
        // console.log(`${selectedObjectRef.current.mesh}`);
        console.log("mesh: ",selectedObjectRef.current);
      } else {
        console.log("Mesh not found");
      }
    }
  }, [meshName]);



  useFrame(() => {
    // ...

    // Check if a mesh is selected
    if (selectedObjectRef.current) {
      // Apply the Outline effect to the selected mesh
      gl.autoClear = true; // Enable automatic clearing of the buffer
      gl.render(camera, cameraRef.current);

      gl.autoClear = false; // Disable automatic clearing to render the outline
      gl.clearDepth();
      gl.render(camera, cameraRef.current);
    }
  });


  return (
    <>
      <PerspectiveCamera ref={cameraRef} makeDefault position={[0, 0, 10]} />
      {/* Add your 3D scene objects here */}
      <primitive object={gltf.scene} />
      {/* <Select enabled={mesh}>
        <mesh ref={selectedObjectRef}>
        </mesh>
    </Select> */}
     {/* <Select enabled={meshName !== ""}>
        <Outline
          blendFunction={THREE.AdditiveBlending}
          visibleEdgeColor="red"
          hiddenEdgeColor="red"
          edgeStrength={2}
          edgeThickness={2}
        />
        <mesh ref={selectedObjectRef}>
          <meshBasicMaterial color={selectedMeshName === meshName ? 0xff0000 : 0xffffff} />
        </mesh>
      </Select> */}
    </>
  );
};
